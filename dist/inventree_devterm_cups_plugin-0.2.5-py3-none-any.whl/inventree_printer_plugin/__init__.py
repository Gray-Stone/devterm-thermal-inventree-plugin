from .plugin import InvenTreeDevtermCupsPlugin

__all__ = ["InvenTreeDevtermCupsPlugin"]
